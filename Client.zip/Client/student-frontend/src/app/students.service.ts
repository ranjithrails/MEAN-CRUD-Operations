import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class StudentsService {
  uri = 'http://localhost:4001/students';

  constructor(private http: HttpClient) { }
  getStudents() {
    return this
           .http
           .get(`${this.uri}`);
  }

  addStudent(first_name, last_name, dob, dept, country) {
    const obj = {
      fname: first_name,
      lname: last_name,
      dob : dob,
      dept: dept,
      country : country
    };
    console.log(obj);
    this.http.post(`${this.uri}`, obj)
        .subscribe(res => console.log('Done'));
  }
  editStudent(id) {
    return this
            .http
            .get(`${this.uri}/${id}`);
    }

  updateStudent(first_name, last_name, dob, dept, country,id)  {
    const obj = {
      fname: first_name,
      lname: last_name,
      dob : dob,
      dept: dept,
      country : country
    };
    this
      .http
      .patch(`${this.uri}/${id}`, obj)
      .subscribe(res => console.log('Done'));
  }

  deleteStudent(id) {
    return this
              .http
              .delete(`${this.uri}/${id}`);
  }

}
