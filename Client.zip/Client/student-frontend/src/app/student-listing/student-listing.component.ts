import { Component, OnInit } from '@angular/core';
import Student from '../Student';
import {StudentsService} from '../students.service';


@Component({
  selector: 'app-student-listing',
  templateUrl: './student-listing.component.html',
  styleUrls: ['./student-listing.component.css']
})
export class StudentListingComponent implements OnInit {
  students: Student[];

  constructor(private studentService: StudentsService) { }

  ngOnInit() {
    this.studentService
    .getStudents()
    .subscribe((data: any) => {
      this.students = data.students;
  });
  }
  deleteStudent(id) {
    this.studentService.deleteStudent(id).subscribe(res => {
      console.log('Deleted');
      this.studentService
      .getStudents()
      .subscribe((data: any) => {
        this.students = data.students;
    });
    });
  }


}
