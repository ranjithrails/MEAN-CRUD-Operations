import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import {StudentsService} from '../students.service';

@Component({
  selector: 'app-student-edit',
  templateUrl: './student-edit.component.html',
  styleUrls: ['./student-edit.component.css']
})
export class StudentEditComponent implements OnInit {
  student: any = {};
  angForm: FormGroup;

  constructor(private route: ActivatedRoute,private router: Router,private fb: FormBuilder, private studentService: StudentsService) { 
    this.createForm();
  }

  createForm() {
    this.angForm = this.fb.group({
      first_name: ['', Validators.required ],
      last_name: ['', Validators.required ],
      dob: ['', Validators.required ],
      dept:['', Validators.required],
      country: ['', Validators.required]
    });
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.studentService.editStudent(params['id']).subscribe(res => {
        this.student = res;
    });
  });
  }

  updateStudent(first_name, last_name, dob, dept, country) {
    this.route.params.subscribe(params => {
       this.studentService.updateStudent(first_name, last_name, dob, dept, country, params['id']);
       this.router.navigate(['students']);
 });
}

}
