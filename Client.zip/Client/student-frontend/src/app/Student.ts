export default class Business {
  first_name: String;
  last_name: String;
  dob: String;
  dept: String;
  country: String;
}