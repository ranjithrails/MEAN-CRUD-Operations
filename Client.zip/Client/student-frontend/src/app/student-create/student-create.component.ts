import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import {StudentsService} from '../students.service';

@Component({
  selector: 'app-student-create',
  templateUrl: './student-create.component.html',
  styleUrls: ['./student-create.component.css']
})
export class StudentCreateComponent implements OnInit {

  angForm: FormGroup;
  constructor(private route: ActivatedRoute,private router: Router,private fb: FormBuilder, private studentService: StudentsService) {
    this.createForm();
  }

  createForm() {
    this.angForm = this.fb.group({
      first_name: ['', Validators.required ],
      last_name: ['', Validators.required ],
      dob: ['', Validators.required ],
      dept:['', Validators.required],
      country: ['', Validators.required]
    });
  }

  addStudent(first_name, last_name, dob, dept, country) {
    this.studentService.addStudent(first_name, last_name, dob, dept, country);
    this.router.navigate(['students']);
  }

  ngOnInit() {
  }

}
